import React, { useState } from "react";
import NavigationMenu from './components/Navbar';
import JedinicaMere from './components/JedinicaMere';
import Tarifa from './components/Tarifa'; 
import FakturaDetalji from './components/FakturaDetalji'; 
import FakturaLista from './components/FakturaLista'; 
import Godina from './components/Godina';
import Komitent from './components/Komitent';
import StavkeFakture from './components/StavkeFakture';
import RekapitulacijaPoreza from './components/RekapitulacijaPoreza';
import ObracunCena from './components/ObracunCena';
import FakturaForm from './components/FakturaForm';
import './styles.css';


function App() {
  const [fakture, setFakture] = useState([
    {
      idfakture: 1,
      godina: 2024,
      redniBroj: 1,
      datumDokumenta: "2024-04-01",
      datumPrometa: "2024-04-05",
      idkomitenta: 1,
      vrednostBezPoreza: 1000,
      vrednostSaPorezom: 1200,
    },
    {
      idfakture: 2,
      godina: 2024,
      redniBroj: 2,
      datumDokumenta: "2024-05-01",
      datumPrometa: "2024-05-05",
      idkomitenta:2,
      vrednostBezPoreza: 1500,
      vrednostSaPorezom: 1800,
    },
    
  ]);
  

  const [odabranaFaktura, setOdabranaFaktura] = useState(null);

  const prikaziDetaljeFakture = (faktura) => {
    setOdabranaFaktura(faktura);
 
  };
  
  return (
    <div className="app">
      <NavigationMenu/>
      <FakturaLista fakture={fakture} prikaziDetaljeFakture={prikaziDetaljeFakture} />
      {odabranaFaktura && <FakturaDetalji faktura={odabranaFaktura} />}
      
      <JedinicaMere/>
      <Tarifa/>
  
    </div>
  );
}

export default App;
