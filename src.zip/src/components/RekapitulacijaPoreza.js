import React from 'react';

const RekapitulacijaPoreza = ({ porezi }) => {
  
  const ukupanPorezPoStopi = {};
  porezi.forEach((porez) => {
    if (!ukupanPorezPoStopi[porez.stopa]) {
      ukupanPorezPoStopi[porez.stopa] = 0;
    }
    ukupanPorezPoStopi[porez.stopa] += porez.iznos;
  });

  return (
    <div>
      <h2>Rekapitulacija poreza</h2>
      <table>
        <thead>
          <tr>
            <th>Poreska stopa (%)</th>
            <th>Ukupan porez</th>
          </tr>
        </thead>
        <tbody>
          {Object.keys(ukupanPorezPoStopi).map((stopa, index) => (
            <tr key={index}>
              <td>{stopa}</td>
              <td>{ukupanPorezPoStopi[stopa].toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default RekapitulacijaPoreza;