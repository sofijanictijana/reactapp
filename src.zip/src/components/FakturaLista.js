import React from 'react';

const FakturaLista = ({ fakture, prikaziDetaljeFakture }) => {
  return (
    <div className="faktura-lista-container">
      <h2>Lista Faktura</h2>
      <table className="faktura-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Godina</th>
            <th>Datum Dokumenta</th>
            <th>Datum Prometa</th>
            <th>Komitent</th>
            <th>Vrednost bez poreza</th>
            <th>Vrednost sa porezom</th>
            <th>Akcije</th>
          </tr>
        </thead>
        <tbody>
          {fakture.map((faktura) => (
            <tr key={faktura.idfakture}>
              <td>{faktura.idfakture}</td>
              <td>{faktura.godina}</td>
              <td>{faktura.datumDokumenta}</td>
              <td>{faktura.datumPrometa}</td>
              <td>{faktura.idkomitenta}</td>
              <td>{faktura.vrednostBezPoreza}</td>
              <td>{faktura.vrednostSaPorezom}</td>
              <td>
                <button className="button-6" onClick={() => prikaziDetaljeFakture(faktura)}>Detalji</button>
              </td>
            
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}



export default FakturaLista;
