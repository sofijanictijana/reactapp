import React, { useState } from "react";

function Komitent() {
  const [komitenti, setKomitenti] = useState([
    { sifra: "001", pib: "123456789", maticni_broj: "987654321", naziv: "Komitent 1" },
    { sifra: "002", pib: "987654321", maticni_broj: "123456789", naziv: "Komitent 2" },
    { sifra: "003", pib: "111222333", maticni_broj: "444555666", naziv: "Komitent 3" },
  ]);

  return (
    <div className="komitent-container">
      <h2>Komitenti</h2>
      <div className="lista-komitenti">
        <ul>
          {komitenti.map((komitent, index) => (
            <li key={index}>
              <strong>Šifra:</strong> {komitent.sifra}, <strong>PIB:</strong> {komitent.pib}, <strong>Matični broj:</strong> {komitent.maticni_broj}, <strong>Naziv:</strong> {komitent.naziv}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Komitent;
