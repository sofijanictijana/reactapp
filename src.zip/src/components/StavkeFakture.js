import React, { useState } from "react";

function StavkaFakture({ dodajStavku }) {
  const [stavka, setStavka] = useState({
    idstavkaFakture: Math.floor(Math.random() * 1000), // Random ID stavke fakture
    idfakture: "", // Unos korisnika
    idartikal: "", // Unos korisnika
    idtarife: "", // Unos korisnika
    porez: "", // Unos korisnika
    kolicina: "", // Unos korisnika
    prodajnaCena: "", // Unos korisnika
    rabat: "", // Unos korisnika
    maloprodajnaCena: "", // Automatski računata
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setStavka((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!stavka.idfakture || !stavka.idartikal || !stavka.idtarife || !stavka.porez || !stavka.kolicina || !stavka.prodajnaCena) {
      alert("Sva polja moraju biti popunjena.");
      return;
    }

    // Računanje maloprodajne cene
    const maloprodajnaCena = parseFloat(stavka.prodajnaCena) * (1 + parseFloat(stavka.porez) / 100) * (1 - parseFloat(stavka.rabat) / 100);
    setStavka((prevState) => ({
      ...prevState,
      maloprodajnaCena: maloprodajnaCena.toFixed(2),
    }));

    dodajStavku({ ...stavka, maloprodajnaCena: maloprodajnaCena.toFixed(2) });

    // Resetujemo polja forme nakon dodavanja
    setStavka({
      idstavkaFakture: Math.floor(Math.random() * 1000),
      idfakture: "",
      idartikal: "",
      idtarife: "",
      porez: "",
      kolicina: "",
      prodajnaCena: "",
      rabat: "",
      maloprodajnaCena: "",
    });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <h2>Unos nove stavke fakture</h2>
        <div className="div-container-nova-stavka">
          <div>
            <label className="label">ID Fakture:</label>
            <input
              type="text"
              className="input"
              name="idfakture"
              value={stavka.idfakture}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">ID Artikla:</label>
            <input
              type="text"
              className="input"
              name="idartikal"
              value={stavka.idartikal}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">ID Tarife:</label>
            <input
              type="text"
              className="input"
              name="idtarife"
              value={stavka.idtarife}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">Porez (%):</label>
            <input
              type="number"
              className="input"
              name="porez"
              value={stavka.porez}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">Količina:</label>
            <input
              type="number"
              className="input"
              name="kolicina"
              value={stavka.kolicina}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">Prodajna cena:</label>
            <input
              type="number"
              className="input"
              name="prodajnaCena"
              value={stavka.prodajnaCena}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="label">Rabat (%):</label>
            <input
              type="number"
              className="input"
              name="rabat"
              value={stavka.rabat}
              onChange={handleChange}
            />
          </div>
          <div>
            <label className="label">Maloprodajna cena:</label>
            <input
              type="text"
              className="input"
              name="maloprodajnaCena"
              value={stavka.maloprodajnaCena}
              readOnly
            />
          </div>
        </div>
        <button className="button-6" role="button" type="submit">
          Dodaj stavku
        </button>
      </form>
    </div>
  );
}

export default StavkaFakture;
