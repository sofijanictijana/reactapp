

import React from 'react';

const NavigationMenu = ({ setActivePage }) => {
  return (
    <div className="navigation-menu">
      <h2>Fakturisanje</h2>
      <ul>
        <li onClick={() => setActivePage('prikazFaktura')}>Prikaz faktura</li>
        <li onClick={() => setActivePage('prikazFaktura')}>Jedinica mere</li>
        <li onClick={() => setActivePage('prikazFaktura')}>Tarifa</li>
        
      </ul>
    </div>
  );
}

export default NavigationMenu;
