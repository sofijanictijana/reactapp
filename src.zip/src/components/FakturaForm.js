import React, { useState } from "react";

function FakturaForm({ faktura, dodajFakturu }) {
  const [showModal, setShowModal] = useState(false);
  const [formaFaktura, setFormaFaktura] = useState({
    idfakture: "",
    godina: "",
    redniBroj: "",
    datumDokumenta: "",
    datumPrometa: "",
    idkomitenta: "",
    vrednostBezPoreza: "",
    vrednostSaPorezom: "",
    stavke: [], // Niz za stavke fakture
  });
  const [novaStavka, setNovaStavka] = useState({
    idstavka: "",
    idartikal: "",
    idtarifa: "",
    porez: "",
    kolicina: "",
    prodajnaCena: "",
    rabat: "",
    maloprodajnaCena: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormaFaktura({ ...formaFaktura, [name]: value });
  };

  const handleStavkaChange = (e) => {
    const { name, value } = e.target;
    setNovaStavka({ ...novaStavka, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dodajFakturu(formaFaktura);
    setFormaFaktura({
      idfakture: "",
      godina: "",
      redniBroj: "",
      datumDokumenta: "",
      datumPrometa: "",
      idkomitenta: "",
      vrednostBezPoreza: "",
      vrednostSaPorezom: "",
      stavke: [],
    });
  };

  const dodajStavku = () => {
    setFormaFaktura({
      ...formaFaktura,
      stavke: [...formaFaktura.stavke, novaStavka],
    });
    setNovaStavka({
      idstavka: "",
      idartikal: "",
      idtarifa: "",
      porez: "",
      kolicina: "",
      prodajnaCena: "",
      rabat: "",
      maloprodajnaCena: "",
    });
  };

  const handlePrint = () => {
    // Implementacija logike za štampanje fakture
    alert("Faktura se štampa...");
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <h2>Unos Fakture</h2>
        <label>
          ID Fakture:
          <input
            type="text"
            name="idfakture"
            value={formaFaktura.idfakture}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Godina:
          <input
            type="text"
            name="godina"
            value={formaFaktura.godina}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Redni Broj:
          <input
            type="text"
            name="redniBroj"
            value={formaFaktura.redniBroj}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Datum Dokumenta:
          <input
            type="date"
            name="datumDokumenta"
            value={formaFaktura.datumDokumenta}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Datum Prometa:
          <input
            type="date"
            name="datumPrometa"
            value={formaFaktura.datumPrometa}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          ID Komitenta:
          <input
            type="text"
            name="idkomitenta"
            value={formaFaktura.idkomitenta}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Vrednost Bez Poreza:
          <input
            type="number"
            name="vrednostBezPoreza"
            value={formaFaktura.vrednostBezPoreza}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Vrednost Sa Porezom:
          <input
            type="number"
            name="vrednostSaPorezom"
            value={formaFaktura.vrednostSaPorezom}
            onChange={handleChange}
            required
          />
        </label>
        <button className="button-6" type="submit">
          Dodaj Fakturu
        </button>
        <button
          className="button-6"
          type="button"
          onClick={() => setShowModal(true)}
        >
          Prikaži stavke fakture
        </button>
        <button className="button-6" type="button" onClick={handlePrint}>
          Štampaj fakturu
        </button>
      </form>

      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <span
              className="close"
              onClick={() => setShowModal(false)}
            >
              &times;
            </span>
            <h2>Stavke Fakture</h2>
            <form onSubmit={(e) => {
              e.preventDefault();
              dodajStavku();
            }}>
              <label>
                ID Stavke:
                <input
                  type="text"
                  name="idstavka"
                  value={novaStavka.idstavka}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                ID Artikla:
                <input
                  type="text"
                  name="idartikal"
                  value={novaStavka.idartikal}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                ID Tarife:
                <input
                  type="text"
                  name="idtarifa"
                  value={novaStavka.idtarifa}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                Porez:
                <input
                  type="number"
                  name="porez"
                  value={novaStavka.porez}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                Količina:
                <input
                  type="number"
                  name="kolicina"
                  value={novaStavka.kolicina}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                Prodajna Cena:
                <input
                  type="number"
                  name="prodajnaCena"
                  value={novaStavka.prodajnaCena}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                Rabat:
                <input
                  type="number"
                  name="rabat"
                  value={novaStavka.rabat}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <label>
                Maloprodajna Cena:
                <input
                  type="number"
                  name="maloprodajnaCena"
                  value={novaStavka.maloprodajnaCena}
                  onChange={handleStavkaChange}
                  required
                />
              </label>
              <button type="submit" className="button-6">
                Dodaj Stavku
              </button>
            </form>
            <ul>
              {formaFaktura.stavke.map((stavka, index) => (
                <li key={index}>
                  {stavka.idstavka} - {stavka.idartikal} - {stavka.idtarifa} - {stavka.porez} - {stavka.kolicina} - {stavka.prodajnaCena} - {stavka.rabat} - {stavka.maloprodajnaCena}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

export default FakturaForm;
