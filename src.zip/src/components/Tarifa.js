import React, { useState } from "react";

function Tarifa() {
  // Statički podaci o tarifama
  const [tarife, setTarife] = useState([
    { id: 1, naziv: "Tarifa 1", procenat: 10 },
    { id: 2, naziv: "Tarifa 2", procenat: 15 },
    { id: 3, naziv: "Tarifa 3", procenat: 20 },
  ]);
  const [novaTarifa, setNovaTarifa] = useState("");
  const [noviProcenat, setNoviProcenat] = useState("");

  // Funkcija za dodavanje nove tarife
  const dodajTarifu = () => {
    if (novaTarifa.trim() !== "" && noviProcenat.trim() !== "") {
      const postoji = tarife.some(
        (tarifa) => tarifa.naziv.toLowerCase() === novaTarifa.toLowerCase()
      );
      if (!postoji) {
        const novaTarifaObj = {
          id: tarife.length + 1,
          naziv: novaTarifa,
          procenat: parseFloat(noviProcenat), // Parsiramo procenat u float
        };
        setTarife([...tarife, novaTarifaObj]);
        setNovaTarifa("");
        setNoviProcenat("");
      } else {
        alert("Tarifa već postoji.");
      }
    } else {
      alert("Naziv tarife i procenat su obavezni.");
    }
  };

  return (
    <div className="forma-container">
      <h2>Tarife</h2>
      <div className="grid-container-forma">
        {/* Prikaz tarifa */}
        <div className="lista-forma">
          <ul>
            {tarife.map((tarifa) => (
              <li key={tarifa.id}>{tarifa.naziv} - {tarifa.procenat}%</li>
            ))}
          </ul>
        </div>
        {/* Forma za unos nove tarife */}
        <div className="forma-unos">
          <label htmlFor="naziv_tarife" className="label">
            Naziv tarife:
          </label>
          <input
            type="text"
            value={novaTarifa}
            onChange={(e) => setNovaTarifa(e.target.value)}
            placeholder="Unesite novu tarifu"
            className="input"
            name="naziv_tarife"
            id="naziv_tarife"
          />
          <label htmlFor="procenat" className="label">
            Procenat:
          </label>
          <input
            type="text"
            value={noviProcenat}
            onChange={(e) => setNoviProcenat(e.target.value)}
            placeholder="Unesite procenat"
            className="input"
            name="procenat"
            id="procenat"
          />
          <button className="button-6" onClick={dodajTarifu}>
            Dodaj
          </button>
        </div>
      </div>
    </div>
  );
}

export default Tarifa;
