import React, { useState } from 'react';

const ObracunCena = () => {
  const [maloprodajnaCena, setMaloprodajnaCena] = useState('');
  const [rabat, setRabat] = useState('');
  const [prodajnaCena, setProdajnaCena] = useState('');

  // Implementirajte funkcionalnost za automatski obračun cena

  return (
    <div>
      <h2>Obracun cena</h2>
      {/* Dodajte input polja za unos maloprodajne cene i rabata */}
    </div>
  );
}

export default ObracunCena;
