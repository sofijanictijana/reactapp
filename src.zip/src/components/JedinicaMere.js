import React, { useState } from "react";

function JedinicaMere() {
  // Statički podaci o jedinicama mere
  const [jediniceMere, setJediniceMere] = useState([
    { id: 1, naziv: "Kilogram (kg)" },
    { id: 2, naziv: "Komad (kom)" },
    { id: 3, naziv: "Litar (l)" },
  ]);
  const [novaJedinica, setNovaJedinica] = useState("");

  // Funkcija za dodavanje nove jedinice mere
  const dodajJedinicuMere = () => {
    if (novaJedinica.trim() !== "") {
      const postoji = jediniceMere.some(
        (jedinica) => jedinica.naziv.toLowerCase() === novaJedinica.toLowerCase()
      );
      if (!postoji) {
        const novaJedinicaMere = {
          id: jediniceMere.length + 1,
          naziv: novaJedinica,
        };
        setJediniceMere([...jediniceMere, novaJedinicaMere]);
        setNovaJedinica("");
      } else {
        alert("Jedinica mere već postoji.");
      }
    }
  };

  return (
    <div className="forma-container">
      <h2>Jedinice mere robe</h2>
      <div className="grid-container-forma">
        {/* Prikaz jedinica mere */}
        <div className="lista-forma">
          <ul>
            {jediniceMere.map((jedinica) => (
              <li key={jedinica.id}>{jedinica.naziv}</li>
            ))}
          </ul>
        </div>
        {/* Forma za unos nove jedinice mere */}
        <div className="forma-unos">
          <label htmlFor="jedinica_mere" className="label">
            Naziv jedinice mere:
          </label>
          <input
            type="text"
            value={novaJedinica}
            onChange={(e) => setNovaJedinica(e.target.value)}
            placeholder="Unesite novu jedinicu mere"
            className="input"
            name="jedinica_mere"
            id="jedinica_mere"
          />
          <button className="button-6" onClick={dodajJedinicuMere}>
            Dodaj
          </button>
        </div>
      </div>
    </div>
  );
}

export default JedinicaMere;
