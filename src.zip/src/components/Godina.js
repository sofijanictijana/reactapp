import React from "react";

function Godina() {

  const godine = [
    { idgodina: 1, godina: 2022, oddatuma: "01-01-2022", dodatuma: "31-12-2022" },
    { idgodina: 2, godina: 2023, oddatuma: "01-01-2023", dodatuma: "31-12-2023" },
    { idgodina: 3, godina: 2024, oddatuma: "01-01-2024", dodatuma: "31-12-2024" },
  ];

  return (
    <div className="godina-container">
      <h2>Godine</h2>
      <div className="lista-godine">
        <ul>
          {godine.map((godina) => (
            <li key={godina.idgodina}>
              <strong>ID godine:</strong> {godina.idgodina}, <strong>Godina:</strong> {godina.godina}, <strong>Od datuma:</strong> {godina.oddatuma}, <strong>Do datuma:</strong> {godina.dodatuma}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Godina;
