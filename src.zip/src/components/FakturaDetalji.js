import React, { useState } from "react";

function FakturaDetalji({ faktura, izmeniFakturu, obrisiFakturu, stampajFakturu }) {
  const [novaFaktura, setNovaFaktura] = useState(faktura);
  const [stavke, setStavke] = useState(faktura.stavke || []);
  const [newStavka, setNewStavka] = useState({
    id: "",
    idfakture: faktura.id,
    idartikal: "",
    idtarife: "",
    porez: "",
    kolicina: "",
    prodajnaCena: "",
    rabat: "",
    maloprodajnaCena: ""
  });
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNovaFaktura({ ...novaFaktura, [name]: value });
  };

  const handleStavkaChange = (e) => {
    const { name, value } = e.target;
    setNewStavka({ ...newStavka, [name]: value });
  };

  const handleAddStavka = () => {
    setStavke([...stavke, newStavka]);
    setNewStavka({
      id: "",
      idfakture: faktura.id,
      idartikal: "",
      idtarife: "",
      porez: "",
      kolicina: "",
      prodajnaCena: "",
      rabat: "",
      maloprodajnaCena: ""
    });
  };

  const handleDeleteStavka = (index) => {
    const updatedStavke = stavke.filter((_, i) => i !== index);
    setStavke(updatedStavke);
  };

  const handleIzmeniClick = () => {
    if (!novaFaktura.godina || !novaFaktura.redniBroj || !novaFaktura.datumDokumenta || !novaFaktura.datumPrometa || !novaFaktura.idkomitenta || !novaFaktura.vrednostBezPoreza || !novaFaktura.vrednostSaPorezom) {
      alert("Sva polja moraju biti popunjena.");
      return;
    }
    izmeniFakturu({ ...novaFaktura, stavke });
    setShowSuccessMessage(true);
  };

  const handleDeleteClick = () => {
    if (window.confirm("Da li ste sigurni da želite da obrišete ovu fakturu?")) {
      obrisiFakturu(faktura.id);
    }
  };

  const handlePrint = () => {
    alert("Faktura se štampa...");
  };
  

  return (
    <div className="faktura-detalji-container">
      <h2>Detalji Fakture</h2>
      {showSuccessMessage && <p className="success-message">Faktura je uspešno sačuvana.</p>}
      <form>
      <label htmlFor="redniBroj" className="label">Redni Broj:</label>
        <input
          type="text"
          value={novaFaktura.redniBroj}
          onChange={handleChange}
          placeholder="Unesite redni broj"
          className="input"
          name="redniBroj"
          id="redniBroj"
        />
        <label htmlFor="godina" className="label">Godina:</label>
        <input
          type="text"
          value={novaFaktura.godina}
          onChange={handleChange}
          placeholder="Unesite godinu"
          className="input"
          name="godina"
          id="godina"
        />
   
        <label htmlFor="datumDokumenta" className="label">Datum Dokumenta:</label>
        <input
          type="date"
          value={novaFaktura.datumDokumenta}
          onChange={handleChange}
          className="input"
          name="datumDokumenta"
          id="datumDokumenta"
        />
        <label htmlFor="datumPrometa" className="label">Datum Prometa:</label>
        <input
          type="date"
          value={novaFaktura.datumPrometa}
          onChange={handleChange}
          className="input"
          name="datumPrometa"
          id="datumPrometa"
        />
        <label htmlFor="idkomitenta" className="label">ID Komitenta:</label>
        <input
          type="text"
          value={novaFaktura.idkomitenta}
          onChange={handleChange}
          placeholder="Unesite ID komitenta"
          className="input"
          name="idkomitenta"
          id="idkomitenta"
        />
        <label htmlFor="vrednostBezPoreza" className="label">Vrednost Bez Poreza:</label>
        <input
          type="number"
          value={novaFaktura.vrednostBezPoreza}
          onChange={handleChange}
          placeholder="Unesite vrednost bez poreza"
          className="input"
          name="vrednostBezPoreza"
          id="vrednostBezPoreza"
        />
        <label htmlFor="vrednostSaPorezom" className="label">Vrednost Sa Porezom:</label>
        <input
          type="number"
          value={novaFaktura.vrednostSaPorezom}
          onChange={handleChange}
          placeholder="Unesite vrednost sa porezom"
          className="input"
          name="vrednostSaPorezom"
          id="vrednostSaPorezom"
        />
      </form>
      <br />
      <h3>Stavke Fakture</h3>
      <table className="stavke-table">
        <thead>
          <tr>
            <th>Artikal</th>
            <th>Tarifa</th>
            <th>Porez</th>
            <th>Količina</th>
            <th>Prodajna Cena</th>
            <th>Rabat</th>
            <th>Maloprodajna Cena</th>
            <th>Akcije</th>
          </tr>
        </thead>
        <tbody>
          {stavke.map((stavka, index) => (
            <tr key={index}>
              <td>{stavka.idartikal}</td>
              <td>{stavka.idtarife}</td>
              <td>{stavka.porez}</td>
              <td>{stavka.kolicina}</td>
              <td>{stavka.prodajnaCena}</td>
              <td>{stavka.rabat}</td>
              <td>{stavka.maloprodajnaCena}</td>
              <td>
                <button onClick={() => handleDeleteStavka(index)} className="button-delete">Obriši</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <br />
      <form className="stavke-form">
        <label htmlFor="idartikal" className="label">ID Artikla:</label>
        <input
          type="text"
          value={newStavka.idartikal}
          onChange={handleStavkaChange}
          placeholder="Unesite ID artikla"
          className="input"
          name="idartikal"
          id="idartikal"
        />
        <label htmlFor="idtarife" className="label">ID Tarife:</label>
        <input
          type="text"
          value={newStavka.idtarife}
          onChange={handleStavkaChange}
          placeholder="Unesite ID tarife"
          className="input"
          name="idtarife"
          id="idtarife"
        />
        <label htmlFor="porez" className="label">Porez:</label>
        <input
          type="number"
          value={newStavka.porez}
          onChange={handleStavkaChange}
          placeholder="Unesite porez"
          className="input"
          name="porez"
          id="porez"
        />
        <label htmlFor="kolicina" className="label">Količina:</label>
        <input
          type="number"
          value={newStavka.kolicina}
          onChange={handleStavkaChange}
          placeholder="Unesite količinu"
          className="input"
          name="kolicina"
          id="kolicina"
        />
        <label htmlFor="prodajnaCena" className="label">Prodajna Cena:</label>
        <input
          type="number"
          value={newStavka.prodajnaCena}
          onChange={handleStavkaChange}
          placeholder="Unesite prodajnu cenu"
          className="input"
          name="prodajnaCena"
          id="prodajnaCena"
        />
        <label htmlFor="rabat" className="label">Rabat:</label>
        <input
          type="number"
          value={newStavka.rabat}
          onChange={handleStavkaChange}
          placeholder="Unesite rabat"
          className="input"
          name="rabat"
          id="rabat"
        />
        <label htmlFor="maloprodajnaCena" className="label">Maloprodajna Cena:</label>
        <input
          type="number"
          value={newStavka.maloprodajnaCena}
          onChange={handleStavkaChange}
          placeholder="Unesite maloprodajnu cenu"
          className="input"
          name="maloprodajnaCena"
          id="maloprodajnaCena"
        />
        <button type="button" onClick={handleAddStavka} className="button-6">Dodaj Stavku</button>
      </form>
      <br />
      <div style={{ textAlign: "center" }}>
        <button onClick={handleIzmeniClick} className="button-6">
          Sačuvaj
        </button>
       
        <button onClick={handleDeleteClick} className="button-delete">
          Obriši fakturu
        </button>
        <button onClick={handlePrint} className="button-print">
          Štampaj fakturu
        </button>
      </div>
    </div>
  );
}

export default FakturaDetalji;
