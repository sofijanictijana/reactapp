import React, { useState } from "react";

function Artikal() {
  // Statički podaci o artiklima
  const [artikli, setArtikli] = useState([
    { sifra: "001", naziv: "Artikal 1", jedinica_mere: "Komad (kom)", tarifa: "Tarifa 1", id: 1 },
    { sifra: "002", naziv: "Artikal 2", jedinica_mere: "Kilogram (kg)", tarifa: "Tarifa 2", id: 2 },
    { sifra: "003", naziv: "Artikal 3", jedinica_mere: "Litar (l)", tarifa: "Tarifa 3", id: 3 },
  ]);
  const [novaSifra, setNovaSifra] = useState("");
  const [noviNaziv, setNoviNaziv] = useState("");
  const [novaJedinicaMere, setNovaJedinicaMere] = useState("");
  const [novaTarifa, setNovaTarifa] = useState("");

  // Funkcija za dodavanje novog artikla
  const dodajArtikal = () => {
    if (novaSifra.trim() !== "" && noviNaziv.trim() !== "" && novaJedinicaMere.trim() !== "" && novaTarifa.trim() !== "") {
      const postoji = artikli.some(
        (artikal) => artikal.sifra.toLowerCase() === novaSifra.toLowerCase()
      );
      if (!postoji) {
        const noviArtikal = {
          sifra: novaSifra,
          naziv: noviNaziv,
          jedinica_mere: novaJedinicaMere,
          tarifa: novaTarifa,
          id: artikli.length + 1,
        };
        setArtikli([...artikli, noviArtikal]);
        setNovaSifra("");
        setNoviNaziv("");
        setNovaJedinicaMere("");
        setNovaTarifa("");
      } else {
        alert("Artikal sa tom šifrom već postoji.");
      }
    } else {
      alert("Sifra, naziv, jedinica mere i tarifa su obavezni.");
    }
  };

  return (
    <div className="artikal-container">
      <h2>Artikli</h2>
      <div className="grid-container-artikal">
        {/* Prikaz artikala */}
        <div className="lista-artikal">
          <ul>
            {artikli.map((artikal) => (
              <li key={artikal.id}>
                {artikal.sifra} - {artikal.naziv} - {artikal.jedinica_mere} - {artikal.tarifa}
              </li>
            ))}
          </ul>
        </div>
        {/* Forma za unos novog artikla */}
        <div className="forma-unos">
          <label htmlFor="nova_sifra" className="label">
            Šifra artikla:
          </label>
          <input
            type="text"
            value={novaSifra}
            onChange={(e) => setNovaSifra(e.target.value)}
            placeholder="Unesite novu šifru artikla"
            className="input"
            name="nova_sifra"
            id="nova_sifra"
          />
          <label htmlFor="novi_naziv" className="label">
            Naziv artikla:
          </label>
          <input
            type="text"
            value={noviNaziv}
            onChange={(e) => setNoviNaziv(e.target.value)}
            placeholder="Unesite naziv novog artikla"
            className="input"
            name="novi_naziv"
            id="novi_naziv"
          />
          <label htmlFor="nova_jedinica_mere" className="label">
            Jedinica mere:
          </label>
          <input
            type="text"
            value={novaJedinicaMere}
            onChange={(e) => setNovaJedinicaMere(e.target.value)}
            placeholder="Unesite jedinicu mere"
            className="input"
            name="nova_jedinica_mere"
            id="nova_jedinica_mere"
          />
          <label htmlFor="nova_tarifa" className="label">
            Tarifa:
          </label>
          <input
            type="text"
            value={novaTarifa}
            onChange={(e) => setNovaTarifa(e.target.value)}
            placeholder="Unesite tarifu"
            className="input"
            name="nova_tarifa"
            id="nova_tarifa"
          />
          <button className="button-6" onClick={dodajArtikal}>
            Dodaj artikal
          </button>
        </div>
      </div>
    </div>
  );
}

export default Artikal;
